#include "stm32f4xx.h"
#include "usart.h"
#include "delay.h"
#include "led.h"
#include "lcd.h"
#include "touch.h"
#include "rtc.h"
#include "gpio.h"
#include "key.h"
#include "exti.h"
#include "adc.h"
int main(void)
{
	float distance;
	short temp; 
	RTC_TimeTypeDef RTC_TimeStruct;
	RTC_DateTypeDef RTC_DateStruct;
	u8 tbuf[40];
	u8 t=0;
	uart_init(115200);
	usart2_init(9600);
	delay_init(84);
	LED_Init();
	LCD_Init();
	My_GPIO_Init();
	EXTIX_Init();
	Adc_Init(); 
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	My_RTC_Init();
	RTC_Set_WakeUp(RTC_WakeUpClock_CK_SPRE_16bits,0);		
	
	POINT_COLOR=RED;
	LCD_ShowString(30,30,200,16,16,"TEMPERATE: 00.00C");//���ڹ̶�λ����ʾС����
  while(1){
   USART2_send_byte(0x55);
		delay_ms(1);
		distance = (USART2_RX_BUF[0] <<8)+ USART2_RX_BUF[1];
		if(flag == 2)
		flag = 0;
		//RTC ʵʱʱ��
		t++;
		if((t%10)==0)	
		{

			RTC_GetTime(RTC_Format_BIN,&RTC_TimeStruct);
			
			sprintf((char*)tbuf,"Time:%02d:%02d:%02d",RTC_TimeStruct.RTC_Hours,RTC_TimeStruct.RTC_Minutes,RTC_TimeStruct.RTC_Seconds); 
			LCD_ShowString(30,140,210,16,16,tbuf);	
			
			RTC_GetDate(RTC_Format_BIN, &RTC_DateStruct);
			
			sprintf((char*)tbuf,"Date:20%02d-%02d-%02d",RTC_DateStruct.RTC_Year,RTC_DateStruct.RTC_Month,RTC_DateStruct.RTC_Date); 
			LCD_ShowString(30,160,210,16,16,tbuf);	
			sprintf((char*)tbuf,"Week:%d",RTC_DateStruct.RTC_WeekDay); 
			LCD_ShowString(30,180,210,16,16,tbuf);
		} 
		if((t%20)==0)LED0=!LED0;	
		delay_ms(100);
		printf("%f\r\n",distance);
		
		temp=Get_Temprate();	//�õ��¶�ֵ 
		if(temp<0)
		{
			temp=-temp;
			LCD_ShowString(30+10*8,30,16,16,16,"-");	    //��ʾ����
		}else LCD_ShowString(30+10*8,30,16,16,16," ");	//�޷���
		
		LCD_ShowxNum(30+11*8,30,temp/100,2,16,0);		//��ʾ��������
		LCD_ShowxNum(30+14*8,30,temp%100,2,16,0);		//��ʾС������ 
		 
		//LED0=!LED0;
		//delay_ms(250);
		
		
		//������
		if(distance >= 100 & distance <=300){
			GPIO_ResetBits(GPIOB,GPIO_Pin_8);
		GPIO_SetBits(GPIOB,GPIO_Pin_9);
			delay_ms(100);
		}
		if (distance > 301 & distance <= 500){
			GPIO_ResetBits(GPIOB,GPIO_Pin_9);
			GPIO_SetBits(GPIOB,GPIO_Pin_8);
			delay_ms(100);
		}
		else if (distance < 100 | distance > 500){
		GPIO_ResetBits(GPIOB,GPIO_Pin_9);
		GPIO_ResetBits(GPIOB,GPIO_Pin_8);
		}
		
		//���������Ӳ�����
		//KEY2��KEY3 ��������·������
		
	}
}




